import java.util.Scanner;

public class A1093313_0331 {
    public static void main(String[] args) {
        Animal_0331.showinfo();

        Animal_0331 snow = new Animal_0331("雪寶", 1.1, 52, 100);
        Animal_0331 donkey = new Animal_0331("驢子", 1.5, 99, 200);
        Human_0331 eric = new Human_0331("阿克", 1.9, 80, 150, "男");
        Human_0331 hans = new Human_0331("漢斯", 1.8, 78, 130, "男");
        Snow_0331 anna = new Snow_0331("安那", 1.7, 48, 120, "女", "X");
        Snow_0331 elsa = new Snow_0331("愛沙", 1.7, 50, 120, "女", "Yes");

        snow.show();
        donkey.show();
        eric.show();
        hans.show();
        anna.show();
        elsa.show();

        Scanner scanner = new Scanner(System.in);
        System.out.print("請輸入雪寶的x: ");
        int x = scanner.nextInt();
        System.out.print("請輸入雪寶的y(可為0): ");
        double y = scanner.nextDouble();
        if(y!=0){
            System.out.println("雪寶跑的距離為: " + snow.distance(x, y));
        }
        else{
            System.out.println("雪寶跑的距離為: " + snow.distance(x));
        }

        System.out.print("請輸入驢子的x: ");
        x = scanner.nextInt();
        System.out.print("請輸入驢子的y(可為0): ");
        y = scanner.nextDouble();
        if(y!=0){
            System.out.println("驢子跑的距離為: " + donkey.distance(x, y));
        }
        else{
            System.out.println("驢子跑的距離為: " + donkey.distance(x));
        }

        System.out.print("請輸入阿克的x: ");
        x = scanner.nextInt();
        System.out.print("請輸入阿克的y(可為0): ");
        y = scanner.nextDouble();
        if(y!=0){
            System.out.println("阿克跑的距離為: " + eric.distance(x, y));
        }
        else{
            System.out.println("阿克跑的距離為: " + eric.distance(x));
        }

        System.out.print("請輸入漢斯的x: ");
        x = scanner.nextInt();
        System.out.print("請輸入漢斯的y(可為0): ");
        y = scanner.nextDouble();
        if(y!=0){
            System.out.println("漢斯跑的距離為: " + hans.distance(x, y));
        }
        else{
            System.out.println("漢斯跑的距離為: " + hans.distance(x));
        }

        System.out.print("請輸入安那的x: ");
        x = scanner.nextInt();
        System.out.print("請輸入安那的y(可為0): ");
        y = scanner.nextDouble();
        if(y!=0){
            System.out.println("安那跑的距離為: " + anna.distance(x, y));
        }
        else{
            System.out.println("安那跑的距離為: " + anna.distance(x));
        }

        System.out.print("請輸入愛沙的x: ");
        x = scanner.nextInt();
        System.out.print("請輸入愛沙的y(可為0): ");
        y = scanner.nextDouble();
        if(y!=0){
            System.out.println("愛沙跑的距離為: " + elsa.distance(x, y));
        }
        else{
            System.out.println("愛沙跑的距離為: " + elsa.distance(x));
        }
    }
}

