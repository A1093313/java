public class Human_0331 extends Animal_0331 {
    protected String gender;

    public Human_0331(String name, double height, double weight, double speed, String gender) {
        super(name, height, weight, speed);
        this.gender = gender;
    }

    @Override
    public void show() {
        super.show();
        System.out.println("性別: " + gender);
    }
}

