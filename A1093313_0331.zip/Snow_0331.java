public class Snow_0331 extends Human_0331 {
    protected String freezeSkill;

    public Snow_0331(String name, double height, double weight, double speed, String gender, String freezeSkill) {
        super(name, height, weight, speed, gender);
        this.freezeSkill = freezeSkill;
    }

    @Override
    public void show() {
        super.show();
        System.out.println("冰凍技能: " + freezeSkill);
    }

    @Override
    public double distance(int x, double y) {
        return super.distance(x, y) * 2;
    }

    public double distance(int x) {
        return super.distance(x) * 2;
    }
}

