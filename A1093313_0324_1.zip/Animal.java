public class Animal {

            private String name;
            private double height;
            private double weight;
            private double speed;
        
            //Constructor
            public Animal(String name, double height, double weight, double speed) {
                this.name = name;
                this.height = height;
                this.weight = weight;
                this.speed = speed;
            }
        
            //show() 
            public void show() {
                System.out.println("Name:" + name);
                System.out.println("Height: " + height + "m");
                System.out.println("Weight: " + weight + "kg");
                System.out.println("Speed: " + speed + "m/min");
            }
        
            //distance(x, y) 
            public double distance(double x, double y) {
                    return x * y * speed;
            }
        
            //只輸入x的計算
            public double distance(double x) {
                return x * speed;
            }
        
            public String getName() {
                return name;
            }
        
            public double getHeight() {
                return height;
            }
        
            public double getWeight() {
                return weight;
            }
        
            public double getSpeed() {
                return speed;
            }
        }
        


