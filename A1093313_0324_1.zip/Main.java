import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Animal[] animals = new Animal[4];
        animals[0] = new Animal("雪寶", 1.1, 52, 100);
        animals[1] = new Animal("驢子", 1.5, 99, 200);
        animals[2] = new Animal("安那", 1.7, 48, 120);
        animals[3] = new Animal("愛沙", 1.7, 50, 120);

        //印出每個人的資訊
        for (Animal animal : animals) {
            animal.show();
            System.out.println(); 
        }

        // 輸入xy、算跑步距離
        Scanner scanner = new Scanner(System.in);
        for (Animal animal : animals) {
            System.out.print("請輸入" + animal.getName() + "的 x 值：");
            double x = scanner.nextDouble();

            System.out.print("請輸入" + animal.getName() + "的 y 值（如不輸入則帶入預設值）：");
            double y = scanner.nextDouble();
            if (y == 0) { 
                double distance = animal.distance(x);
                System.out.println(animal.getName() + "跑了" + distance + "公尺");
                System.out.println();
            }
            else{
            double distance = animal.distance(x, y);
            System.out.println(animal.getName() + " 跑了 " + distance + "公尺");
            System.out.println(); 
            }
        }
    }
}
